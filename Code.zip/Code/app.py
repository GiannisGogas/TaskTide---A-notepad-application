# Εισαγωγή βιβλιοθηκών που θα χρησιμοποιηθούν.
from flask import Flask, render_template, request, redirect, url_for 
import os


app = Flask(__name__)


# Συνάρτηση για την φόρτωση των εργασιών από το αρχείο αποθήκευσης.
def load_tasks():
    tasks = []
    # Έλεγχος για την ύπαρξη του αρχείου.
    if os.path.exists('tasks.txt'):
        with open('tasks.txt', 'r') as file:
            # Ανάγνωση των γραμμών του αρχείου.
            for line in file:
                # Χωρισμός κάθε γραμμής στη μορφή: Task|Deadline|Priority
                parts = line.strip().split('|')
                if len(parts) == 3:
                    task, deadline, priority = parts
                    # Αποθήκευση του task στο αρχείο.
                    tasks.append((task, deadline, priority))
    return tasks


# Συνάρτηση για την αποθήκευση εργασιών στο αρχείο.
def save_tasks(tasks):
    # Άνοιγμα του αρχείου tasks.txt σε λειτουργία εγγραφής ('w')
    with open('tasks.txt', 'w') as file:
        # Αποθήκευση των εργασίων στη μορφή: Task|Deadline|Priority
        for task, deadline, priority in tasks:
            file.write(f"{task}|{deadline}|{priority}\n")



# Αρχική σελίδα
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Λήψη των δεδομένων από τη φόρμα μέσω της μεθόδου POST
        task = request.form['task']
        deadline = request.form['deadline']
        priority = request.form['priority']
        # Φόρτωση των ήδη υπαρχουσών εργασιών από το αρχείο.
        tasks = load_tasks()
        # Προσθήκη της νέας εργασίας στη λίστα tasks.
        tasks.append((task, deadline, priority))
        # Αποθήκευση της ενημερωμένης λίστας εργασιών στο αρχείο.
        save_tasks(tasks)
        # Ανακατεύθυνση πίσω στην αρχική σελίδα για να εμφανιστεί η νέα λίστα.
        return redirect(url_for('index'))
    
    # Έλεγχος για την ύπαρξη κάποιου φίλτρου προτεραιότητας στα αιτήματα GET.
    filter_priority = request.args.get('filter_priority')
    # Φόρτωση των ήδη υπαρχουσών εργασιών από το αρχείο.
    tasks = load_tasks()
    # Αν υπάρχει φίλτρο, γίνεται ταξινόμηση των εργασιών ανάλογα με την προτεραιότητα.
    if filter_priority:
        tasks = [task for task in tasks if task[2] == filter_priority]
    # Επιστροφή της σελίδας index.html με τις εργασίες ως παράμετρο.
    return render_template('index.html', tasks=tasks)


# Διαγραφή εργασίας
@app.route('/delete/<int:task_index>')
def delete_task(task_index):
    # Φόρτωση των ήδη υπαρχουσών εργασιών από το αρχείο.
    tasks = load_tasks()
    # Ελέγχος αν το index της εργασίας είναι έγκυρο.
    if 0 <= task_index < len(tasks):
        # Διαγραφή της εργασίας από τη λίστα tasks.
        del tasks[task_index]
        # Αποθήκευση της ενημερωμένης λίστας εργασιών στο αρχείο.
        save_tasks(tasks)
    # Ανακατεύθυνση πίσω στην αρχική σελίδα για να εμφανιστεί η ενημερωμένη λίστα.
    return redirect(url_for('index'))


# Επεξεργασία εργασίας
@app.route('/edit/<int:task_index>', methods=['GET', 'POST'])
def edit_task(task_index):
    
    # Φόρτωση των ήδη υπαρχουσών εργασιών από το αρχείο.
    tasks = load_tasks()
    if request.method == 'POST':
        
        # Αν η φόρμα υποβλήθηκε μέσω POST, γίνεται ενημέρωση της εργασίας.
        if 0 <= task_index < len(tasks):
            # Λήψη των ενημερωμένων δεδομένων από τη φόρμα.
            task = request.form['task']
            deadline = request.form['deadline']
            priority = request.form['priority']
            
            # Ενημέρωση της εργασίας στη λίστα tasks.
            tasks[task_index] = (task, deadline, priority)
            
            # Αποθήκευση της ενημερωμένης λίστας εργασιών στο αρχείο.
            save_tasks(tasks)
            
            # Ανακατεύθυνση πίσω στην αρχική σελίδα.
            return redirect(url_for('index'))
    else:
        # Αν η φόρμα ζητήθηκε μέσω της μεθόδου GET, γίνεται φόρτωση των ήδη υπάρχοντων δεδομένων για επεξεργασία.
        if 0 <= task_index < len(tasks):
            task = tasks[task_index]
            # Εμφάνιση της φόρμας επεξεργασίας με τα υπάρχοντα δεδομένα της εργασίας.
            return render_template('edit.html', task=task, task_index=task_index)

    # Σε περίπτωση σφάλματος γίνεται ανακατευθύνση στην αρχική σελίδα.
    return redirect(url_for('index'))



if __name__ == '__main__':
    # Εκκίνηση της εφαρμογής
    app.run(debug=True)
